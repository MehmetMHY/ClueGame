package experiment;

import java.util.*;

public class IntBoard {
	
	private BoardCell[][] grid;
	private Map<BoardCell, Set<BoardCell>> adjMtx;
	private Set<BoardCell> visited;
	private Set<BoardCell> targets;
	private final static int ROW = 4;
	private final static int COL = 4;
	
	
	public IntBoard() {
	}
	
	public void calcAdjacencies() {
		// to be continued
	}
	
	public Set<BoardCell> getAdList(int row, int col) {
		return null;
	}
	
	public void calcTargets(BoardCell startCell, int pathLength) {
		// to be continued
	}
	
	/**
	 * @return Returns targets if generated otherwise returns null
	 */
	public Set<BoardCell> getTargets() {
		return null;
	}

	public BoardCell getCell(int i, int j) {
		return null;
	}

	public Set<BoardCell> getAdjList(BoardCell cell) {
		return null;
	}
}
